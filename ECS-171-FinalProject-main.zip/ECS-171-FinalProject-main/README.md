[![Open in Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://githubtocolab.com/StephenW789/ECS-171-FinalProject/blob/main/ECS171_Final_Project_Group_4.ipynb)

# ECS-171-FinalProject
If you wish to view the exact outputs/figures found in our report, download the ipynb.zip folder, and open the 
jupyter notebook file within there. That one contains all the graphical results.

To evaluate/rerun this jupyter notebook, simply follow the link above to open a Google Colab notebook, and run all cells from there.
